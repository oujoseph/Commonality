// index.js
console.log("hello world!");
require('./app/index');